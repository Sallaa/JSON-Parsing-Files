import java.util.ArrayList;
import java.util.List;

class main {

    // create your objects manually, I won't do it here...
    public House house1 = new House();
    public House house2 = new House();

    public Node doorHouse1 = new Node(null);


    int editDistance = 0;

    private int calculateEditDistance(House house1, House house2){

        editDistance += calculateEdition(house1.activityAreas.get(0), house2.activityAreas.get(0));
        editDistance += calculateDeletion(house2.activityAreas.get(0));


        return editDistance;
    }


    private int calculateEdition (Node nodeHouse1, Node nodeHouse2){

                if (!nodeHouse1.name.equals(nodeHouse2.name) || nodeHouse2.name == null){
                    nodeHouse2.name = nodeHouse1.name;
                    editDistance++;
                }

                if (!nodeHouse1.children.isEmpty()){
                    for (int i = 0; i < nodeHouse1.children.size(); i++){
                        nodeHouse1 = nodeHouse1.children.get(i);
                        nodeHouse2 = (nodeHouse2.children.isEmpty() || nodeHouse2.children.size() < i) ? new Node(nodeHouse2) : nodeHouse2.children.get(i);
                        calculateEdition(nodeHouse1, nodeHouse2);
                    }

                }

        return editDistance;
    }


    private int calculateDeletion(Node node){
        List<Node> nodesToDelete = new ArrayList<>();
        nodesToDelete =  findAllChildren(node, nodesToDelete);

        for (int i = 0; i < nodesToDelete.size(); i++){
            Node nodeDeleted = nodesToDelete.get(i);
            nodeDeleted = null;

            // delete the object and clean house2.activityAreas too
        }

        return editDistance;
    }


    public List<Node> findAllChildren(Node node, List<Node> childrenList){

        childrenList.add(0,node);

        if (!node.children.isEmpty()){
            for(int i=0; i< node.children.size(); i++)
                childrenList = findAllChildren(node, childrenList);
        }

        return childrenList;
    }

    public static void main(String[] args) {

    }
}