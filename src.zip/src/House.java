import java.util.ArrayList;
import java.util.List;

public class House {
    String name;
    List<Node> activityAreas = new ArrayList<>();
}